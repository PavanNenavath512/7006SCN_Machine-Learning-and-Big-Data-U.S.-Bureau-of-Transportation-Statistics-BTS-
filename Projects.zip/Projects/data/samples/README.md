# data/samples/

This directory contains small representative samples of the BTS flight dataset,
intended for local development, unit testing, and schema validation without
requiring a full Google Drive / Colab session.

## Contents

| File | Description | Rows | Size |
|---|---|---|---|
| `sample_jan2024_100rows.csv` | 100-row slice of January 2024 raw CSV | 100 | ~40 KB |
| `sample_features_50rows.csv` | 50-row slice of the engineered features Parquet (exported to CSV) | 50 | ~15 KB |

## Generating Samples

Run the following in any notebook after data has been ingested:

```python
# Raw sample
df.sample(fraction=0.0001, seed=42) \
  .coalesce(1) \
  .write.mode("overwrite") \
  .option("header", "true") \
  .csv("/content/drive/MyDrive/Machine Learning and Big Data/samples/raw_sample")

# Feature sample
features_df.sample(fraction=0.0001, seed=42) \
  .coalesce(1) \
  .write.mode("overwrite") \
  .option("header", "true") \
  .csv("/content/drive/MyDrive/Machine Learning and Big Data/samples/features_sample")
```

Then copy the resulting CSV files into this `data/samples/` directory.

## Usage in Tests

```python
import pandas as pd

RAW_SAMPLE      = "data/samples/sample_jan2024_100rows.csv"
FEATURES_SAMPLE = "data/samples/sample_features_50rows.csv"

raw_df      = pd.read_csv(RAW_SAMPLE)
features_df = pd.read_csv(FEATURES_SAMPLE)
```

## Notes

- Samples are provided for offline/local testing only.
- Do **not** use samples for model training or evaluation.
- The full dataset (≥1 GB across 6 monthly BTS CSV files) must be used
  for all production runs in Google Colab.
