# BTS Flight Delay Prediction
### 7006SCN — Machine Learning and Big Data | Coventry University

A distributed machine learning pipeline for predicting US domestic flight arrival
delays using the Bureau of Transportation Statistics (BTS) On-Time Reporting
dataset (January–June 2024, >1 GB).

---

## Project Overview

| Item | Detail |
|---|---|
| **Problem** | Binary classification: predict whether a flight will arrive ≥15 minutes late |
| **Dataset** | BTS On-Time Reporting Carrier Performance, 2024 Jan–Jun (~3.2M flights) |
| **Source** | https://www.transtats.bts.gov |
| **Size** | >1 GB across 6 monthly CSV files, 110 raw columns |
| **Algorithms** | Logistic Regression, Decision Tree, Random Forest, Naive Bayes (PySpark MLlib) |
| **Platform** | Google Colab (high-RAM) + Google Drive + PySpark 3.5.1 |
| **Tableau** | [Public Workbook Link — insert here] |

---

## Repository Structure

```
project/
├── notebooks/
│   ├── 1_data_ingestion.ipynb       # CSV → validated Parquet (Snappy)
│   ├── 2_feature_engineering.ipynb  # Feature creation, encoding, splits
│   ├── 3_model_training.ipynb       # Baseline + tuned MLlib models, sklearn comparison
│   └── 4_evaluation.ipynb           # Final test-set evaluation, Tableau D3/D4 exports
├── tableau/
│   ├── dashboard1.twbx              # Data quality & pipeline monitoring
│   ├── dashboard2.twbx              # Model performance & feature importance
│   ├── dashboard3.twbx              # Business insights & recommendations
│   ├── dashboard4.twbx              # Scalability & cost analysis
│   └── README_tableau.md            # Dashboard documentation & connection guide
├── scripts/
│   ├── setup_environment.sh         # One-command environment setup
│   ├── run_pipeline.py              # Orchestrates all 4 notebooks end-to-end
│   └── performance_profiler.py      # Strong/weak scaling & I/O profiling
├── config/
│   ├── spark_config.yaml            # Spark and pipeline configuration
│   └── tableau_config.json          # Tableau data source & design settings
├── data/
│   ├── schemas/
│   │   └── bts_flight_schema.json   # Full raw + engineered feature schema
│   └── samples/
│       └── README.md                # How to generate & use sample data
├── tests/
│   └── test_pipeline.py             # Unit & integration tests (pytest)
├── environment.yml                  # Conda environment specification
├── Dockerfile                       # Reproducible Docker environment
└── README.md                        # This file
```

---

## Pipeline Stages

### 1. Data Ingestion (`1_data_ingestion.ipynb`)
- Mounts Google Drive and initialises SparkSession (12 GB driver, 8 GB executor)
- Loads 6 monthly BTS CSVs and combines via `unionByName`
- Applies 3 data validation rules (year range, non-null Origin/Dest, positive Distance)
- Repartitions by Month + Airline and persists to Parquet (Snappy compression, partitioned by Year/Month)
- Exports 4 CSV tables for Tableau Dashboard 1

### 2. Feature Engineering (`2_feature_engineering.ipynb`)
- Drops 48 irrelevant columns (diversion details, admin IDs, redundant derived cols)
- Fills null delay columns with 0 (no delay = no cause delay); drops rows with null core time fields
- Creates binary target `DelayLabel` from `ArrDel15`
- Engineers 10 new features: `DepHour`, `ArrHour`, `IsWeekend`, `TimeOfDay`, `Season`, `IsHolidayMonth`, `DistanceBucket`, `RouteAvgDelay` (broadcast join), `AirlineDelayRate` (broadcast join), `DelayRiskScore` (custom MLlib transformer)
- Applies StringIndexer + OneHotEncoder on categoricals, StandardScaler on numerics
- Splits temporally: train=Jan–Apr, val=May, test=Jun (held out)

### 3. Model Training (`3_model_training.ipynb`)
- Trains 4 PySpark MLlib baselines: Logistic Regression, Decision Tree (depth 8), Random Forest (20 trees), Naive Bayes
- Cross-validates Decision Tree with `CrossValidator` (3 folds, parallelism=4) and saves best model
- Compares MLlib vs scikit-learn (10% sample, single node) on training time and AUC
- Serialises all 5 models (MLlib format); sklearn models saved as Pickle
- Exports 4 CSV tables for Tableau Dashboard 2

### 4. Evaluation (`4_evaluation.ipynb`)
- Loads held-out June 2024 test set and all serialised models
- Computes AUC, Accuracy, F1, Precision, Recall for all 5 models
- Produces confusion matrices, bootstrap confidence intervals
- Runs `performance_profiler.py` logic inline for scalability data
- Exports CSV tables for Tableau Dashboards 3 and 4

---

## Quick Start

### Option A — Google Colab (recommended)

1. Upload the dataset CSVs to Google Drive under:
   `My Drive/Machine Learning and Big Data/`
2. Open each notebook in Google Colab (File → Open → Google Drive).
3. Run cells top-to-bottom in order: 1 → 2 → 3 → 4.

### Option B — Local (Docker)

```bash
# Build image
docker build -t bts-flight-delay .

# Run JupyterLab
docker run -p 8888:8888 \
  -v $(pwd):/workspace \
  -v /path/to/bts/csv/files:/workspace/data/raw \
  bts-flight-delay
```

Open `http://localhost:8888` and run the notebooks.

### Option C — Local (Conda)

```bash
# Setup environment
bash scripts/setup_environment.sh

conda activate bts_flight

# Run all stages
python scripts/run_pipeline.py

# Or run a single stage
python scripts/run_pipeline.py --stage ingest

# Run performance profiler
python scripts/performance_profiler.py

# Run tests
pytest tests/test_pipeline.py -v
```

---

## Results Summary

| Model | AUC | Accuracy | F1 | Train Time |
|---|---|---|---|---|
| Logistic Regression | — | — | — | — |
| Decision Tree | — | — | — | — |
| Random Forest | — | — | — | — |
| Naive Bayes | — | — | — | — |
| Decision Tree Tuned | — | — | — | — |

*Fill in from your notebook output after running Notebook 4.*

---

## Key Technical Decisions

| Decision | Choice | Justification |
|---|---|---|
| Storage format | Parquet (Snappy) | 3–5× smaller than CSV; columnar for ML feature access |
| Partitioning | Year / Month | Aligns with temporal train/val/test split patterns |
| Persist strategy | `MEMORY_AND_DISK` | Colab RAM limited; spills to disk rather than recomputing |
| Null handling | Fill-zero for delay cols | Domain knowledge: null = no delay from that cause |
| Categorical encoding | StringIndexer + OHE | Required by MLlib pipeline; preserves sparsity |
| Broadcast join | RouteAvgDelay, AirlineDelayRate | Small lookup tables → avoids shuffle |
| Test split | June 2024 (held out entirely) | Temporal holdout; prevents data leakage |

---

## Dataset Citation

Bureau of Transportation Statistics (2024).
*On-Time Reporting Carrier On-Time Performance (1987–present), January–June 2024.*
U.S. Department of Transportation.
https://www.transtats.bts.gov/DL_SelectFields.aspx?gnoyr_VQ=FGJ

---

## Module Information

- **Module:** 7006SCN Machine Learning and Big Data
- **Assessment:** Coursework — Written (Applied Core, 30 credits)
- **Module Leader:** Dr Katerina Stamou
- **Due:** Thursday 03/03/2026, 18:00 UK time
