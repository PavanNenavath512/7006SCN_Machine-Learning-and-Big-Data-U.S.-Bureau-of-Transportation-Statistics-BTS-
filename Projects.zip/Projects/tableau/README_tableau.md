# Tableau Dashboards — BTS Flight Delay Prediction

**Module:** 7006SCN Machine Learning and Big Data
**Tableau Public Workbook:** [INSERT YOUR TABLEAU PUBLIC LINK HERE]

---

## Overview

Four interactive dashboards visualise the full Big Data ML pipeline — from raw
data quality monitoring through to scalability and cost analysis.

| Dashboard | File | Focus |
|---|---|---|
| Dashboard 1 | `dashboard1.twbx` | Data Quality & Pipeline Monitoring |
| Dashboard 2 | `dashboard2.twbx` | Model Performance & Feature Importance |
| Dashboard 3 | `dashboard3.twbx` | Business Insights & Recommendations |
| Dashboard 4 | `dashboard4.twbx` | Scalability & Cost Analysis |

---

## Dashboard 1 — Data Quality & Pipeline Monitoring

**Data sources (CSV from `tableau_exports/`):**

| CSV folder | Content |
|---|---|
| `d1_dataset_overview` | Row counts, column count, partition summary |
| `d1_validation_funnel` | Raw → valid row funnel |
| `d1_missing_values` | Per-column null counts and % missing |
| `d1_monthly_pipeline` | Monthly flight counts, cancellations, avg delay |

**Key views:**
- Validation funnel bar chart (raw vs accepted rows)
- Missing value heatmap by column
- Monthly flight volume trend (Jan–Jun 2024)
- Cancellation & diversion rates by month

---

## Dashboard 2 — Model Performance & Feature Importance

**Data sources:**

| CSV folder | Content |
|---|---|
| `d2_baseline_model_comparison` | AUC, Accuracy, F1 for all 4 models |
| `d2_tuned_vs_baseline_val` | Baseline DT vs. tuned DT on validation |
| `d2_cv_scores` | Cross-validation AUC per param set |
| `d2_feature_importance` | Feature importances from tuned DT |
| `d2_test_set_results` | Final metrics on held-out June 2024 test set |
| `d2_sklearn_vs_mllib` | PySpark MLlib vs scikit-learn comparison |

**Key views:**
- Side-by-side model comparison bar chart (AUC / F1 / Accuracy)
- Feature importance horizontal bar chart (top 15 features)
- CV fold AUC line chart
- MLlib vs sklearn training time scatter

---

## Dashboard 3 — Business Insights & Recommendations

**Data sources:**

| CSV folder | Content |
|---|---|
| `d3_delay_by_airline` | Delay rate per carrier |
| `d3_delay_by_route` | Top N routes by delay rate |
| `d3_delay_by_hour` | Delay rate by departure hour |
| `d3_delay_by_season` | Delay rate by season |
| `d3_delay_risk_distribution` | Distribution of DelayRiskScore |
| `d3_cancellation_analysis` | Cancellation rate by airline/month |

**Key views:**
- Airline delay rate ranked bar chart
- Route delay heatmap (Origin → Dest)
- Hour-of-day delay trend line
- Season delay comparison
- Risk score distribution histogram

**Interactive parameters:**
- `delay_threshold_minutes` — adjust definition of "delayed"
- `top_n_routes` — filter top N routes
- `model_selector` — filter to a specific model

---

## Dashboard 4 — Scalability & Cost Analysis

**Data sources:**

| CSV folder | Content |
|---|---|
| `d4_strong_scaling` | Fixed workload; timing vs data fraction |
| `d4_weak_scaling` | Proportional workload growth |
| `d4_io_throughput` | Parquet read throughput per split |
| `d4_cost_performance` | Cost index vs. performance retained |

**Key views:**
- Strong scaling line chart (time vs fraction)
- Weak scaling efficiency line chart
- I/O throughput comparison bar chart
- Cost-performance trade-off scatter

---

## Connecting Data Sources in Tableau

1. Open each `.twbx` file in Tableau Desktop or upload to Tableau Public.
2. Go to **Data → Edit Connection** for each data source.
3. Navigate to your local `tableau_exports/` folder and select the
   corresponding CSV subfolder.
4. Tableau will read the part-00000-*.csv file automatically.

> **Tip:** If using Tableau Extracts (`.hyper`), right-click the data source
> and select **Extract Data** after connecting for faster rendering.

---

## Design Conventions

| Element | Value |
|---|---|
| Primary colour | `#1F4E79` (dark blue) |
| Delayed highlight | `#C00000` (red) |
| On-time highlight | `#375623` (green) |
| Font | Tableau Book |
| Dashboard size | 1200 × 800 px (desktop) |

---

## LOD Expressions Used

```text
Route average delay:    { FIXED [Origin], [Dest] : AVG([ArrDelay]) }
Airline delay rate:     { FIXED [Reporting_Airline] : AVG([DelayLabel]) }
Overall delay rate:     { FIXED : AVG([DelayLabel]) }
Monthly flight count:   { FIXED [Month] : COUNTD([FlightID]) }
```

---

## Exporting for Stakeholders

To export a dashboard as PDF:
**File → Print to PDF → Entire workbook → Save**

To share on Tableau Public:
**Server → Tableau Public → Save to Tableau Public**
