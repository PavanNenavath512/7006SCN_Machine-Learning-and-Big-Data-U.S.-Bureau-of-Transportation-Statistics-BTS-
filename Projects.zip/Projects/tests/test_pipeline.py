"""
test_pipeline.py
================
BTS Flight Delay Prediction — Unit & Integration Tests

Tests cover:
  - Schema validation (raw and engineered features)
  - Feature engineering logic (DepHour, Season, DelayLabel, etc.)
  - Custom transformer: DelayRiskScorer
  - Data split integrity (no overlap between train / val / test months)
  - Model serialisation round-trip
  - Evaluation metric computations

Run with:
  pytest tests/test_pipeline.py -v

Requirements:
  pytest, pyspark, pandas, numpy
"""

import json
import os
import sys
import tempfile

import numpy as np
import pandas as pd
import pytest
from pyspark.ml.feature import MinMaxScaler, StandardScaler, VectorAssembler
from pyspark.sql import Row, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import (DoubleType, IntegerType, StringType,
                                StructField, StructType)

# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture(scope="session")
def spark():
    """Shared SparkSession for the test session."""
    session = (
        SparkSession.builder
        .master("local[2]")
        .appName("BTS_Tests")
        .config("spark.sql.shuffle.partitions", "4")
        .config("spark.driver.memory", "2g")
        .getOrCreate()
    )
    session.sparkContext.setLogLevel("ERROR")
    yield session
    session.stop()


@pytest.fixture(scope="session")
def raw_schema():
    """Load expected raw schema from JSON."""
    schema_path = os.path.join(
        os.path.dirname(__file__), "..", "data", "schemas", "bts_flight_schema.json"
    )
    with open(schema_path) as f:
        return json.load(f)


@pytest.fixture(scope="session")
def sample_raw_df(spark):
    """Minimal synthetic raw DataFrame mirroring BTS structure."""
    data = [
        Row(Year=2024, Quarter=1, Month=1, DayofMonth=15, DayOfWeek=1,
            Reporting_Airline="AA", Origin="ATL", Dest="ORD",
            CRSDepTime=800, DepTime=810.0, DepDelay=10.0, DepDelayMinutes=10.0,
            DepDel15=0.0, DepartureDelayGroups=0,
            TaxiOut=15.0, WheelsOff=825.0, WheelsOn=950.0, TaxiIn=8.0,
            CRSArrTime=1000, ArrTime=958.0, ArrDelay=-2.0, ArrDelayMinutes=0.0,
            ArrDel15=0.0, ArrivalDelayGroups=-1,
            Cancelled=0.0, Diverted=0.0,
            CRSElapsedTime=120.0, ActualElapsedTime=108.0, AirTime=85.0,
            Distance=606.0, DistanceGroup=3,
            CarrierDelay=None, WeatherDelay=None, NASDelay=None,
            SecurityDelay=None, LateAircraftDelay=None),
        Row(Year=2024, Quarter=1, Month=1, DayofMonth=15, DayOfWeek=5,
            Reporting_Airline="DL", Origin="JFK", Dest="LAX",
            CRSDepTime=1400, DepTime=1420.0, DepDelay=20.0, DepDelayMinutes=20.0,
            DepDel15=1.0, DepartureDelayGroups=1,
            TaxiOut=20.0, WheelsOff=1440.0, WheelsOn=1700.0, TaxiIn=12.0,
            CRSArrTime=1630, ArrTime=1712.0, ArrDelay=42.0, ArrDelayMinutes=42.0,
            ArrDel15=1.0, ArrivalDelayGroups=3,
            Cancelled=0.0, Diverted=0.0,
            CRSElapsedTime=330.0, ActualElapsedTime=352.0, AirTime=320.0,
            Distance=2475.0, DistanceGroup=10,
            CarrierDelay=None, WeatherDelay=None, NASDelay=None,
            SecurityDelay=None, LateAircraftDelay=None),
    ]
    return spark.createDataFrame(data)


# ── Schema Tests ──────────────────────────────────────────────────────────────

class TestSchema:

    def test_raw_schema_file_exists(self, raw_schema):
        assert "fields" in raw_schema, "Schema JSON must contain 'fields' key"
        assert len(raw_schema["fields"]) > 0, "Schema must define at least one field"

    def test_required_raw_columns_present(self, raw_schema, sample_raw_df):
        """All non-nullable schema fields must exist in the DataFrame."""
        required = [f["name"] for f in raw_schema["fields"] if not f["nullable"]]
        df_cols  = set(sample_raw_df.columns)
        for col in required:
            assert col in df_cols, f"Required column missing: {col}"

    def test_engineered_features_defined(self, raw_schema):
        """Engineered features section must define DelayLabel and key features."""
        names = [f["name"] for f in raw_schema["engineered_features"]]
        for expected in ["DelayLabel", "DepHour", "Season", "DelayRiskScore"]:
            assert expected in names, f"Engineered feature missing from schema: {expected}"


# ── Validation Tests ──────────────────────────────────────────────────────────

class TestValidation:

    def test_year_filter(self, spark):
        """Rows with out-of-range Year must be filtered out."""
        data = [
            Row(Year=2024, Month=1, Origin="ATL", Dest="ORD", Distance=500.0),
            Row(Year=1800, Month=1, Origin="ATL", Dest="ORD", Distance=500.0),
            Row(Year=2030, Month=1, Origin="ATL", Dest="ORD", Distance=500.0),
        ]
        df = spark.createDataFrame(data)
        filtered = df.filter(F.col("Year").between(1987, 2025))
        assert filtered.count() == 1

    def test_null_origin_dest_filtered(self, spark):
        """Rows with null Origin or Dest must be dropped."""
        data = [
            Row(Year=2024, Month=1, Origin="ATL", Dest="ORD", Distance=500.0),
            Row(Year=2024, Month=1, Origin=None, Dest="ORD",  Distance=500.0),
            Row(Year=2024, Month=1, Origin="ATL", Dest=None,  Distance=500.0),
        ]
        df = spark.createDataFrame(data)
        filtered = df.filter(F.col("Origin").isNotNull() & F.col("Dest").isNotNull())
        assert filtered.count() == 1

    def test_negative_distance_filtered(self, spark):
        """Rows with Distance ≤ 0 must be rejected."""
        data = [
            Row(Year=2024, Month=1, Origin="ATL", Dest="ORD", Distance=606.0),
            Row(Year=2024, Month=1, Origin="ATL", Dest="ORD", Distance=-10.0),
            Row(Year=2024, Month=1, Origin="ATL", Dest="ORD", Distance=0.0),
        ]
        df = spark.createDataFrame(data)
        filtered = df.filter(F.col("Distance").isNull() | (F.col("Distance") > 0))
        assert filtered.count() == 2


# ── Feature Engineering Tests ─────────────────────────────────────────────────

class TestFeatureEngineering:

    @pytest.fixture(scope="class")
    def engineered_df(self, spark, sample_raw_df):
        """Apply feature engineering transformations to sample data."""
        df = sample_raw_df
        df = df.fillna(0, subset=["CarrierDelay","WeatherDelay","NASDelay",
                                   "SecurityDelay","LateAircraftDelay",
                                   "ArrDelay","ArrDelayMinutes","ArrDel15",
                                   "DepDelay","DepDelayMinutes","DepDel15"])
        df = df.withColumn("DelayLabel",
                F.when(F.col("ArrDel15") == 1.0, 1).otherwise(0).cast("integer"))
        df = df.withColumn("DepHour",
                (F.col("CRSDepTime") / 100).cast("integer"))
        df = df.withColumn("ArrHour",
                (F.col("CRSArrTime") / 100).cast("integer"))
        df = df.withColumn("IsWeekend",
                F.when(F.col("DayOfWeek").isin([6, 7]), 1).otherwise(0))
        df = df.withColumn("TimeOfDay",
                F.when(F.col("DepHour") < 6,  "Night")
                 .when(F.col("DepHour") < 12, "Morning")
                 .when(F.col("DepHour") < 18, "Afternoon")
                 .otherwise("Evening"))
        df = df.withColumn("Season",
                F.when(F.col("Month").isin([12, 1, 2]), "Winter")
                 .when(F.col("Month").isin([3, 4, 5]),  "Spring")
                 .when(F.col("Month").isin([6, 7, 8]),  "Summer")
                 .otherwise("Autumn"))
        df = df.withColumn("IsHolidayMonth",
                F.when(F.col("Month").isin([1, 7, 11, 12]), 1).otherwise(0))
        df = df.withColumn("DistanceBucket",
                F.when(F.col("Distance") < 500,  "Short")
                 .when(F.col("Distance") < 1500, "Medium")
                 .otherwise("Long"))
        return df

    def test_delay_label_binary(self, engineered_df):
        """DelayLabel must be 0 or 1 only."""
        values = {r["DelayLabel"] for r in engineered_df.select("DelayLabel").collect()}
        assert values.issubset({0, 1}), f"Unexpected DelayLabel values: {values}"

    def test_delay_label_correct(self, engineered_df):
        """Row with ArrDel15=1 → DelayLabel=1; ArrDel15=0 → DelayLabel=0."""
        rows = engineered_df.select("ArrDel15", "DelayLabel").collect()
        for r in rows:
            expected = 1 if r["ArrDel15"] == 1.0 else 0
            assert r["DelayLabel"] == expected

    def test_dep_hour_range(self, engineered_df):
        """DepHour must be in [0, 23]."""
        result = engineered_df.select(
            F.min("DepHour").alias("mn"),
            F.max("DepHour").alias("mx")
        ).first()
        assert 0 <= result["mn"] <= 23
        assert 0 <= result["mx"] <= 23

    def test_season_values(self, engineered_df):
        """Season must be one of the four valid values."""
        valid = {"Winter", "Spring", "Summer", "Autumn"}
        values = {r["Season"] for r in engineered_df.select("Season").collect()}
        assert values.issubset(valid), f"Unexpected Season values: {values}"

    def test_january_is_winter(self, engineered_df):
        """January rows must have Season=Winter."""
        jan = engineered_df.filter(F.col("Month") == 1).select("Season").collect()
        assert all(r["Season"] == "Winter" for r in jan)

    def test_distance_bucket_logic(self, engineered_df):
        """ATL-ORD (606mi) → Medium; JFK-LAX (2475mi) → Long."""
        rows = {
            r["Distance"]: r["DistanceBucket"]
            for r in engineered_df.select("Distance", "DistanceBucket").collect()
        }
        assert rows[606.0]  == "Medium"
        assert rows[2475.0] == "Long"

    def test_is_weekend_monday(self, engineered_df):
        """DayOfWeek=1 (Monday) → IsWeekend=0."""
        mon = engineered_df.filter(F.col("DayOfWeek") == 1).select("IsWeekend").first()
        assert mon["IsWeekend"] == 0

    def test_is_holiday_month_january(self, engineered_df):
        """January → IsHolidayMonth=1."""
        jan = engineered_df.filter(F.col("Month") == 1).select("IsHolidayMonth").first()
        assert jan["IsHolidayMonth"] == 1


# ── Custom Transformer Tests ──────────────────────────────────────────────────

class TestDelayRiskScorer:

    def test_risk_score_range(self, spark):
        """DelayRiskScore must be clipped to [0, 1]."""
        data = [
            Row(RouteAvgDelay=30.0, AirlineDelayRate=0.25, IsWeekend=1, IsHolidayMonth=1),
            Row(RouteAvgDelay=0.0,  AirlineDelayRate=0.0,  IsWeekend=0, IsHolidayMonth=0),
            Row(RouteAvgDelay=200.0, AirlineDelayRate=1.0, IsWeekend=1, IsHolidayMonth=1),  # clipped
        ]
        df = spark.createDataFrame(data)
        df = df.withColumn(
            "DelayRiskScore",
            F.least(
                F.greatest(
                    F.round(
                        (F.col("RouteAvgDelay") / 120.0 * 0.40) +
                        (F.col("AirlineDelayRate") * 0.30) +
                        (F.col("IsWeekend").cast("double") * 0.15) +
                        (F.col("IsHolidayMonth").cast("double") * 0.15),
                        4
                    ),
                    F.lit(0.0)
                ),
                F.lit(1.0)
            )
        )
        scores = [r["DelayRiskScore"] for r in df.select("DelayRiskScore").collect()]
        assert all(0.0 <= s <= 1.0 for s in scores), f"Scores out of [0,1]: {scores}"

    def test_higher_risk_inputs_produce_higher_score(self, spark):
        """Row with higher delay history should produce a higher risk score."""
        data = [
            Row(RouteAvgDelay=5.0,  AirlineDelayRate=0.10, IsWeekend=0, IsHolidayMonth=0),
            Row(RouteAvgDelay=60.0, AirlineDelayRate=0.50, IsWeekend=1, IsHolidayMonth=1),
        ]
        df = spark.createDataFrame(data)
        df = df.withColumn(
            "DelayRiskScore",
            F.least(
                F.greatest(
                    F.round(
                        (F.col("RouteAvgDelay") / 120.0 * 0.40) +
                        (F.col("AirlineDelayRate") * 0.30) +
                        (F.col("IsWeekend").cast("double") * 0.15) +
                        (F.col("IsHolidayMonth").cast("double") * 0.15),
                        4
                    ),
                    F.lit(0.0)
                ),
                F.lit(1.0)
            )
        )
        scores = [r["DelayRiskScore"] for r in df.select("DelayRiskScore").collect()]
        assert scores[1] > scores[0], "Higher-risk inputs should produce higher score"


# ── Data Split Tests ──────────────────────────────────────────────────────────

class TestDataSplits:

    TRAIN_MONTHS = {1, 2, 3, 4}
    VAL_MONTHS   = {5}
    TEST_MONTHS  = {6}

    def test_no_month_overlap(self):
        """Train / val / test month sets must be disjoint."""
        all_splits = [self.TRAIN_MONTHS, self.VAL_MONTHS, self.TEST_MONTHS]
        for i, a in enumerate(all_splits):
            for j, b in enumerate(all_splits):
                if i != j:
                    assert a.isdisjoint(b), f"Month overlap between split {i} and {j}"

    def test_all_months_covered(self):
        """Jan–Jun must be fully assigned to a split."""
        all_months = self.TRAIN_MONTHS | self.VAL_MONTHS | self.TEST_MONTHS
        assert all_months == {1, 2, 3, 4, 5, 6}

    def test_train_largest_split(self):
        """Training set should be the largest split."""
        assert len(self.TRAIN_MONTHS) > len(self.VAL_MONTHS)
        assert len(self.TRAIN_MONTHS) > len(self.TEST_MONTHS)


# ── Config Tests ──────────────────────────────────────────────────────────────

class TestConfig:

    def test_spark_config_exists(self):
        config_path = os.path.join(
            os.path.dirname(__file__), "..", "config", "spark_config.yaml"
        )
        assert os.path.exists(config_path), "spark_config.yaml not found"

    def test_tableau_config_exists(self):
        config_path = os.path.join(
            os.path.dirname(__file__), "..", "config", "tableau_config.json"
        )
        assert os.path.exists(config_path), "tableau_config.json not found"

    def test_tableau_config_valid_json(self):
        config_path = os.path.join(
            os.path.dirname(__file__), "..", "config", "tableau_config.json"
        )
        with open(config_path) as f:
            cfg = json.load(f)
        assert "data_sources" in cfg
        assert "design" in cfg

    def test_spark_config_required_keys(self):
        import yaml
        config_path = os.path.join(
            os.path.dirname(__file__), "..", "config", "spark_config.yaml"
        )
        with open(config_path) as f:
            cfg = yaml.safe_load(f)
        for key in ["memory", "shuffle", "paths", "models", "splits"]:
            assert key in cfg, f"Missing required key in spark_config.yaml: {key}"


# ── Null Handling Tests ───────────────────────────────────────────────────────

class TestNullHandling:

    def test_fill_zero_removes_nulls(self, spark):
        """fillna(0) on delay cause cols must eliminate nulls."""
        fill_cols = ["CarrierDelay", "WeatherDelay", "NASDelay"]
        schema = StructType([StructField(c, DoubleType(), True) for c in fill_cols])
        data = [(None, None, None), (5.0, None, 0.0)]
        df = spark.createDataFrame(data, schema)
        df = df.fillna(0, subset=fill_cols)
        for col in fill_cols:
            null_count = df.filter(F.col(col).isNull()).count()
            assert null_count == 0, f"Null remaining in {col} after fillna"

    def test_drop_if_null_removes_rows(self, spark):
        """dropna on critical cols must remove rows with nulls."""
        schema = StructType([
            StructField("CRSDepTime", IntegerType(), True),
            StructField("CRSArrTime", IntegerType(), True),
        ])
        data = [(800, 1000), (None, 1000), (800, None)]
        df = spark.createDataFrame(data, schema)
        df = df.dropna(subset=["CRSDepTime", "CRSArrTime"])
        assert df.count() == 1
