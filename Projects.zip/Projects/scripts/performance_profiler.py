"""
performance_profiler.py
=======================
BTS Flight Delay Prediction — Scalability & Performance Profiler

Measures strong scaling, weak scaling, and I/O throughput across
different data fractions and executor configurations.

Results are saved to:
  - logs/profiler_<timestamp>.json   (raw results)
  - tableau_exports/d4_strong_scaling.csv
  - tableau_exports/d4_weak_scaling.csv
  - tableau_exports/d4_io_throughput.csv
  - tableau_exports/d4_cost_performance.csv

Usage:
  python scripts/performance_profiler.py [--features-path PATH]
                                         [--tableau-path PATH]
                                         [--fractions 0.25 0.5 1.0]
"""

import argparse
import json
import logging
import os
import time
from datetime import datetime
from pathlib import Path

# ── Logging ───────────────────────────────────────────────────────────────────
os.makedirs("logs", exist_ok=True)
TIMESTAMP = datetime.now().strftime("%Y%m%d_%H%M%S")
LOG_FILE  = f"logs/profiler_{TIMESTAMP}.json"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger(__name__)


# ── Defaults ──────────────────────────────────────────────────────────────────
DEFAULT_FEATURES_PATH = "/content/drive/MyDrive/Machine Learning and Big Data/features_parquet"
DEFAULT_TABLEAU_PATH  = "/content/drive/MyDrive/Machine Learning and Big Data/tableau_exports"
DEFAULT_FRACTIONS     = [0.25, 0.50, 0.75, 1.00]


def build_spark(app_name: str, shuffle_partitions: int = 200):
    """Build a SparkSession with the project's standard config."""
    from pyspark.sql import SparkSession
    return (
        SparkSession.builder
        .appName(app_name)
        .config("spark.driver.memory", "12g")
        .config("spark.executor.memory", "8g")
        .config("spark.sql.shuffle.partitions", str(shuffle_partitions))
        .config("spark.sql.adaptive.enabled", "true")
        .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
        .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
        .config("spark.memory.fraction", "0.8")
        .getOrCreate()
    )


# ── Strong Scaling ────────────────────────────────────────────────────────────
def profile_strong_scaling(spark, features_path: str, fractions: list) -> list:
    """
    Strong scaling: fixed workload (full dataset), vary data fraction
    to simulate resource increase (more executors → process fraction faster).
    Records wall-clock time and throughput per fraction.
    """
    from pyspark.ml.classification import RandomForestClassifier

    log.info("── Strong Scaling Profile ──────────────────────")
    train_df = spark.read.parquet(features_path + "/train")
    total_rows = train_df.count()
    log.info(f"   Total train rows: {total_rows:,}")

    results = []
    for frac in fractions:
        log.info(f"   Fraction {frac:.2f}  ({int(frac * total_rows):,} rows)")
        sample = train_df.sample(fraction=frac, seed=42)
        sample.cache()
        _ = sample.count()

        rf = RandomForestClassifier(
            featuresCol="scaledFeatures",
            labelCol="DelayLabel",
            numTrees=10,
            maxDepth=5,
            seed=42,
        )
        t0 = time.time()
        rf.fit(sample)
        elapsed = round(time.time() - t0, 3)

        n_rows = int(frac * total_rows)
        throughput = round(n_rows / elapsed, 1) if elapsed > 0 else 0

        row = {
            "fraction":          frac,
            "rows_trained":      n_rows,
            "train_time_sec":    elapsed,
            "throughput_rows_s": throughput,
        }
        results.append(row)
        log.info(f"     Done — {elapsed}s  |  {throughput} rows/s")
        sample.unpersist()

    return results


# ── Weak Scaling ──────────────────────────────────────────────────────────────
def profile_weak_scaling(spark, features_path: str, fractions: list) -> list:
    """
    Weak scaling: problem size grows proportionally with simulated resources.
    Records how train time grows as data volume increases.
    """
    from pyspark.ml.classification import DecisionTreeClassifier

    log.info("── Weak Scaling Profile ────────────────────────")
    train_df = spark.read.parquet(features_path + "/train")
    total_rows = train_df.count()

    results = []
    for frac in fractions:
        n_rows = int(frac * total_rows)
        sample = train_df.sample(fraction=frac, seed=42)
        sample.cache()
        _ = sample.count()

        dt = DecisionTreeClassifier(
            featuresCol="scaledFeatures",
            labelCol="DelayLabel",
            maxDepth=8,
            seed=42,
        )
        t0 = time.time()
        dt.fit(sample)
        elapsed = round(time.time() - t0, 3)

        row = {
            "fraction":       frac,
            "rows_trained":   n_rows,
            "train_time_sec": elapsed,
            "efficiency":     round(fractions[0] * elapsed / (frac * elapsed + 1e-9), 4),
        }
        results.append(row)
        log.info(f"   Fraction {frac:.2f}  →  {elapsed}s")
        sample.unpersist()

    return results


# ── I/O Throughput ────────────────────────────────────────────────────────────
def profile_io_throughput(spark, features_path: str) -> list:
    """Measure Parquet read throughput for train / val / test splits."""
    log.info("── I/O Throughput Profile ──────────────────────")
    splits = ["train", "val", "test"]
    results = []

    for split in splits:
        path = features_path + f"/{split}"
        t0 = time.time()
        df = spark.read.parquet(path)
        n  = df.count()
        elapsed = round(time.time() - t0, 3)
        mb_per_sec = round((n * 0.001) / (elapsed + 1e-9), 2)  # rough estimate

        row = {
            "split":        split,
            "rows":         n,
            "read_time_s":  elapsed,
            "est_mb_per_s": mb_per_sec,
        }
        results.append(row)
        log.info(f"   {split:<6}  {n:>10,} rows  |  {elapsed}s  |  ~{mb_per_sec} MB/s")

    return results


# ── Cost-Performance ──────────────────────────────────────────────────────────
def build_cost_performance(strong_results: list) -> list:
    """
    Simulate cost-performance trade-off.
    Assumes cost scales linearly with the fraction of compute used.
    Base cost index = 1.0 at fraction=1.0.
    """
    max_time = max(r["train_time_sec"] for r in strong_results)
    base_cost = 1.0

    results = []
    for r in strong_results:
        cost_index    = round(r["fraction"] * base_cost, 4)
        time_saving   = round((max_time - r["train_time_sec"]) / max_time * 100, 2)
        cost_saving   = round((1 - r["fraction"]) * 100, 2)
        perf_retained = round((r["throughput_rows_s"] / (strong_results[-1]["throughput_rows_s"] + 1e-9)) * 100, 2)

        results.append({
            "fraction":       r["fraction"],
            "cost_index":     cost_index,
            "time_saving_pct":  time_saving,
            "cost_saving_pct":  cost_saving,
            "perf_retained_pct": perf_retained,
        })

    return results


# ── Save CSV ──────────────────────────────────────────────────────────────────
def save_csv(spark, data: list, out_path: str, label: str) -> None:
    from pyspark.sql import Row
    df = spark.createDataFrame([Row(**r) for r in data])
    df.coalesce(1).write.mode("overwrite").option("header", "true").csv(out_path)
    log.info(f"   Saved {label}  →  {out_path}")


# ── Main ──────────────────────────────────────────────────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(description="BTS Flight Delay — Performance Profiler")
    parser.add_argument("--features-path", default=DEFAULT_FEATURES_PATH)
    parser.add_argument("--tableau-path",  default=DEFAULT_TABLEAU_PATH)
    parser.add_argument("--fractions", nargs="+", type=float, default=DEFAULT_FRACTIONS)
    args = parser.parse_args()

    os.makedirs(args.tableau_path, exist_ok=True)

    log.info("=" * 52)
    log.info("  BTS Flight Delay — Performance Profiler")
    log.info(f"  Fractions : {args.fractions}")
    log.info("=" * 52)

    spark = build_spark("BTS_Performance_Profiler")

    all_results = {}

    # Strong scaling
    strong = profile_strong_scaling(spark, args.features_path, args.fractions)
    all_results["strong_scaling"] = strong
    save_csv(spark, strong, f"{args.tableau_path}/d4_strong_scaling", "d4_strong_scaling")

    # Weak scaling
    weak = profile_weak_scaling(spark, args.features_path, args.fractions)
    all_results["weak_scaling"] = weak
    save_csv(spark, weak, f"{args.tableau_path}/d4_weak_scaling", "d4_weak_scaling")

    # I/O throughput
    io = profile_io_throughput(spark, args.features_path)
    all_results["io_throughput"] = io
    save_csv(spark, io, f"{args.tableau_path}/d4_io_throughput", "d4_io_throughput")

    # Cost-performance
    cost_perf = build_cost_performance(strong)
    all_results["cost_performance"] = cost_perf
    save_csv(spark, cost_perf, f"{args.tableau_path}/d4_cost_performance", "d4_cost_performance")

    # Save raw JSON log
    with open(LOG_FILE, "w") as f:
        json.dump(all_results, f, indent=2)
    log.info(f"\n  Raw results saved: {LOG_FILE}")

    log.info("\n  Profiling complete.")
    spark.stop()


if __name__ == "__main__":
    main()
