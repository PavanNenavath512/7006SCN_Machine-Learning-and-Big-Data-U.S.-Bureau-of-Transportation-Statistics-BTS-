#!/usr/bin/env bash
# =============================================================================
# setup_environment.sh
# BTS Flight Delay Prediction — Environment Setup Script
# =============================================================================
set -euo pipefail

echo "=============================================="
echo "  BTS Flight Delay — Environment Setup"
echo "=============================================="

# ── Python version check ──────────────────────────────────────────────────────
REQUIRED_PYTHON="3.9"
PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}' | cut -d. -f1,2)

echo "[1/6] Checking Python version..."
if python3 -c "import sys; exit(0 if sys.version_info >= (3,9) else 1)"; then
    echo "      Python $PYTHON_VERSION — OK"
else
    echo "      ERROR: Python >= $REQUIRED_PYTHON required. Found $PYTHON_VERSION."
    exit 1
fi

# ── Java check (required for PySpark) ────────────────────────────────────────
echo "[2/6] Checking Java..."
if command -v java &>/dev/null; then
    JAVA_VERSION=$(java -version 2>&1 | awk -F '"' '{print $2}')
    echo "      Java $JAVA_VERSION — OK"
else
    echo "      WARNING: Java not found. PySpark requires Java 8 or 11."
    echo "      Install: sudo apt-get install openjdk-11-jdk"
fi

# ── Conda environment ─────────────────────────────────────────────────────────
echo "[3/6] Setting up Conda environment..."
ENV_NAME="bts_flight"

if conda env list | grep -q "^${ENV_NAME}"; then
    echo "      Environment '$ENV_NAME' already exists — updating..."
    conda env update -n "$ENV_NAME" -f environment.yml --prune
else
    echo "      Creating environment '$ENV_NAME'..."
    conda env create -f environment.yml
fi

echo "      Environment ready."

# ── Activate and validate key packages ───────────────────────────────────────
echo "[4/6] Validating key packages..."
conda run -n "$ENV_NAME" python3 -c "
import pyspark; print(f'      PySpark  : {pyspark.__version__}')
import sklearn; print(f'      sklearn  : {sklearn.__version__}')
import pandas;  print(f'      pandas   : {pandas.__version__}')
import numpy;   print(f'      numpy    : {numpy.__version__}')
"

# ── JAVA_HOME for PySpark ─────────────────────────────────────────────────────
echo "[5/6] Setting JAVA_HOME..."
if [[ -z "${JAVA_HOME:-}" ]]; then
    JAVA_PATH=$(dirname $(dirname $(readlink -f $(which java) 2>/dev/null || echo "")))
    if [[ -d "$JAVA_PATH" ]]; then
        export JAVA_HOME="$JAVA_PATH"
        echo "      JAVA_HOME set to: $JAVA_HOME"
        echo "      Add to your shell profile: export JAVA_HOME=$JAVA_HOME"
    else
        echo "      WARNING: Could not auto-detect JAVA_HOME. Set it manually."
    fi
else
    echo "      JAVA_HOME already set: $JAVA_HOME"
fi

# ── Directory structure ───────────────────────────────────────────────────────
echo "[6/6] Creating project directories..."
DIRS=(
    "data/raw"
    "data/schemas"
    "data/samples"
    "data/parquet"
    "data/features"
    "data/checkpoints"
    "models"
    "logs"
    "tableau_exports"
)

for dir in "${DIRS[@]}"; do
    mkdir -p "$dir"
    echo "      Created: $dir"
done

echo ""
echo "=============================================="
echo "  Setup complete!"
echo ""
echo "  Activate environment:"
echo "    conda activate $ENV_NAME"
echo ""
echo "  Run the pipeline:"
echo "    python scripts/run_pipeline.py"
echo "=============================================="
