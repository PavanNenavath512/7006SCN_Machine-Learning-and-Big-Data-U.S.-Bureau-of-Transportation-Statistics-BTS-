"""
run_pipeline.py
===============
BTS Flight Delay Prediction — End-to-End Pipeline Runner

Orchestrates the full pipeline in sequence:
  1. Data Ingestion       (notebooks/1_data_ingestion.ipynb)
  2. Feature Engineering  (notebooks/2_feature_engineering.ipynb)
  3. Model Training       (notebooks/3_model_training.ipynb)
  4. Evaluation           (notebooks/4_evaluation.ipynb)

Usage:
  python scripts/run_pipeline.py [--stage STAGE] [--config CONFIG]

Options:
  --stage   Run only a specific stage: ingest | features | train | evaluate
            Default: all (runs all stages in order)
  --config  Path to spark_config.yaml (default: config/spark_config.yaml)
  --help    Show this help message
"""

import argparse
import logging
import os
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

import yaml

# ── Logging setup ─────────────────────────────────────────────────────────────
os.makedirs("logs", exist_ok=True)
LOG_FILE = f"logs/pipeline_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(LOG_FILE),
    ],
)
log = logging.getLogger(__name__)

# ── Stage definitions ─────────────────────────────────────────────────────────
STAGES = {
    "ingest":   "notebooks/1_data_ingestion.ipynb",
    "features": "notebooks/2_feature_engineering.ipynb",
    "train":    "notebooks/3_model_training.ipynb",
    "evaluate": "notebooks/4_evaluation.ipynb",
}


def load_config(config_path: str) -> dict:
    """Load Spark configuration from YAML."""
    path = Path(config_path)
    if not path.exists():
        log.warning(f"Config not found at {config_path}. Using defaults.")
        return {}
    with open(path) as f:
        cfg = yaml.safe_load(f)
    log.info(f"Config loaded from {config_path}")
    return cfg


def run_notebook(notebook_path: str, timeout_minutes: int = 120) -> bool:
    """
    Execute a Jupyter notebook via nbconvert.
    Returns True if execution succeeded, False otherwise.
    """
    nb_path = Path(notebook_path)
    if not nb_path.exists():
        log.error(f"Notebook not found: {notebook_path}")
        return False

    out_path = nb_path.with_name(nb_path.stem + "_executed.ipynb")
    cmd = [
        "jupyter", "nbconvert",
        "--to", "notebook",
        "--execute",
        "--inplace",
        f"--ExecutePreprocessor.timeout={timeout_minutes * 60}",
        "--output", str(out_path),
        str(nb_path),
    ]

    log.info(f"Executing: {notebook_path}")
    t0 = time.time()
    try:
        result = subprocess.run(
            cmd,
            check=True,
            capture_output=True,
            text=True,
            timeout=timeout_minutes * 60 + 30,
        )
        elapsed = round(time.time() - t0, 1)
        log.info(f"  ✓ Completed in {elapsed}s  →  {out_path}")
        return True

    except subprocess.CalledProcessError as e:
        elapsed = round(time.time() - t0, 1)
        log.error(f"  ✗ FAILED after {elapsed}s")
        log.error(f"  STDERR: {e.stderr[-2000:]}")
        return False

    except subprocess.TimeoutExpired:
        log.error(f"  ✗ Timed out after {timeout_minutes} minutes")
        return False


def print_summary(results: dict, total_time: float) -> None:
    """Print a final pipeline run summary."""
    log.info("")
    log.info("=" * 52)
    log.info("  PIPELINE SUMMARY")
    log.info("=" * 52)
    for stage, (success, elapsed) in results.items():
        status = "✓ PASSED" if success else "✗ FAILED"
        log.info(f"  {stage:<12}  {status}  ({elapsed:.1f}s)")
    log.info("-" * 52)
    all_passed = all(s for s, _ in results.values())
    log.info(f"  Total time : {total_time:.1f}s")
    log.info(f"  Outcome    : {'SUCCESS' if all_passed else 'FAILED'}")
    log.info(f"  Log file   : {LOG_FILE}")
    log.info("=" * 52)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="BTS Flight Delay — Pipeline Runner"
    )
    parser.add_argument(
        "--stage",
        choices=list(STAGES.keys()) + ["all"],
        default="all",
        help="Pipeline stage to execute (default: all)",
    )
    parser.add_argument(
        "--config",
        default="config/spark_config.yaml",
        help="Path to Spark config YAML (default: config/spark_config.yaml)",
    )
    args = parser.parse_args()

    cfg = load_config(args.config)

    stages_to_run = (
        list(STAGES.items())
        if args.stage == "all"
        else [(args.stage, STAGES[args.stage])]
    )

    log.info("=" * 52)
    log.info("  BTS Flight Delay Prediction — Pipeline")
    log.info(f"  Started : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    log.info(f"  Stages  : {[s for s, _ in stages_to_run]}")
    log.info("=" * 52)

    results = {}
    pipeline_start = time.time()

    for stage_name, nb_path in stages_to_run:
        timeout = cfg.get("pipeline", {}).get("notebook_timeout_minutes", 120)
        t0 = time.time()
        success = run_notebook(nb_path, timeout_minutes=timeout)
        elapsed = time.time() - t0
        results[stage_name] = (success, elapsed)

        if not success:
            log.error(f"Pipeline halted at stage: {stage_name}")
            break

    total_time = time.time() - pipeline_start
    print_summary(results, total_time)

    all_passed = all(s for s, _ in results.values())
    sys.exit(0 if all_passed else 1)


if __name__ == "__main__":
    main()
